#include <time.h>

static void drawtab(int nwins, int first, Monitor *m);
static void alttabstart(const Arg *arg);
static void alttabend();
