static void swaptags(const Arg *arg);

