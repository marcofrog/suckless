static void tagtoleft(const Arg *arg);
static void tagtoright(const Arg *arg);
static void viewtoleft(const Arg *arg);
static void viewtoright(const Arg *arg);
static void tagandviewtoleft(const Arg *arg);
static void tagandviewtoright(const Arg *arg);

