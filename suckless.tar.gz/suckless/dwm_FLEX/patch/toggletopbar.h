static void toggletopbar(const Arg *arg);
