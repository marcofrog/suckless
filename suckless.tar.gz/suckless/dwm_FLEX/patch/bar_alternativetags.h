static void togglealttag();

