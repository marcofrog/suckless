static void togglefakefullscreen(const Arg *arg);

