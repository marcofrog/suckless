#define OPAQUE                  0xffU

static void xinitvisual();

