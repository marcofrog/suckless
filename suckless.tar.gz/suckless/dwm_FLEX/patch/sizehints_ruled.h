static void checkfloatingrules(Client *c);

