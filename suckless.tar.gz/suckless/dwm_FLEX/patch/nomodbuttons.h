static void togglenomodbuttons(const Arg *arg);

